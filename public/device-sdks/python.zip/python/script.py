from AWSIoTPythonSDK.MQTTLib import AWSIoTMQTTClient
import time

def messageCallback(client, userdata, message):
  # message.payload will contain on/off signals, use this to control your device

myMQTTClient = AWSIoTMQTTClient("AOTNEXTUSER-YOUR_DEVICE_SERIAL_NUMBER")
myMQTTClient.configureEndpoint("a3gydrlwsa86zj.iot.ap-southeast-1.amazonaws.com", 8883)
myMQTTClient.configureCredentials("certs/root-CA.crt", "certs/private.pem.key", "certs/certificate.pem.crt")
myMQTTClient.connect()
myMQTTClient.subscribe("YOUR_DEVICE_SERIAL_NUMBER", 1, messageCallback)
while True:
    time.sleep(1)
